password="holaquetal"
total=0
#repeticiones=int(input("número de veces: "))
for j in range (len(password)):
    print(password[j])