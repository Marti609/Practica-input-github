# 41. Imprime el siguiente patrón utilizando for:
for i in range(5, 0, -1):
    for j in range(i, 0, -1):
        print(j, end='')
    print(end=' ')