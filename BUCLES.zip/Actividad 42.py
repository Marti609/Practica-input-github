# 42. Imprima el siguiente patrón con el ciclo for. 
for i in range(1, 5+1):
    print('*' * i)
for i in range(5-2, 0, -1):
    print('*' * i)

