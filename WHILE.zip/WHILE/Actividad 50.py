# 50. Realiza un programa que de los buenos días 3 veces. Con While
contador=0

while contador<3:
    print("Buenos dias")
    contador+=1
