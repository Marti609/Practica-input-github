var1=int(input("introduce el primer valor: "))
var2=int(input("introduce el segundo valor: "))

if var1==var2:
    print("son iguales")

if var1!=var2:
    print("son distintos")