#29. Busca Internet qué función permite obtener la longitud de un String, realiza un programa que al introducir una frase devuelva la longitud
#Pedimos al usuario que introduzca una frase
frase=input("introduce una frase: ")

#Calculamos la longitud de la frase
longitud_frase=len(frase)

#Mostramos por pantalla el resultado
print(f"la longitud de la frase es de {longitud_frase}")