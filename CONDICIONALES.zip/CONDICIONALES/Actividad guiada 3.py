print("menu")
print("1. hamburguesa")
print("2. pizza")
print("3. lentejas")
print("4. bocadillo de jamon")

var1=int(input("escoge un numero: "))

if var1==1:
    print("has escogido hamburguesa")    
elif var1==2:
    print("has escogido pizza")
elif var1==3:
    print("has escogido lentejas")
elif var1==4:
    print("has escogido bocadillo de jamon")
else:
    print("error")