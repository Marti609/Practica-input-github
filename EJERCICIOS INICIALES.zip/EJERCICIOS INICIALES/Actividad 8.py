#pedimos al usuario que introduzca un numero
Hora=float(input("introduce un numero de horas para pasarlo a minutos y a segundos"))
#realizamos los calculos
Minutos=Hora*60
Segundos=Hora*3600
#mostramos por pantalla el resultado
print("el numero de minutos son:", Minutos)
print("el numero de segundos son:", Segundos)


