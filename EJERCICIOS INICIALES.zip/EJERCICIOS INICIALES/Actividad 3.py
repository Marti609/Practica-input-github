#solicitar 2 enteros
entero1 = int(input("introduce un numero entero"))
entero2 = int(input("introduce otro numero entero"))

#realizamos la suma de los dos enteros
suma = entero1+entero2 

#mostramos por pantalla el resultado
print("el resultado de la suma de los dos numeros enteros es:", suma)
