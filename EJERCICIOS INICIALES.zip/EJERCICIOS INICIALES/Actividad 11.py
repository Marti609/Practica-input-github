#pedimos que introduzca un numero
numero1=float(input("introduce la longitud de un lado del cuadrado: "))
#hacemos los calculos
perimetro=numero1*4
area=numero1*numero1
#mostramos por pantalla el resultado
print("El perimetro es:",perimetro)
print("El area es:",area)
