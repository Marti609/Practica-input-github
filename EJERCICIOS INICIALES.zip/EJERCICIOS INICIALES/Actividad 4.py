#solicitar dos numeros decimales
decimal1 = float(input("introduce un numero decimal"))
decimal2 = float(input("introduce otro numero decimal"))

#realizamos la suma
suma = decimal1+decimal2

#mostramos por pantalla el resultado
print 
("el resultado de la suma es:", suma)